
package Client;

import com.sun.org.apache.bcel.internal.generic.InstructionConstants;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
public class Client {
    public static void main(String[] args) throws IOException {
     new ClientGUI().setVisible(true);
     
    }
    
}
