package Server;

import com.sun.org.apache.bcel.internal.generic.InstructionConstants;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

public class Server {

    public static void main(String[] args) throws IOException {
        
        new ServerGUI().setVisible(true);

    }

}
